# config file

# variables and paths

path1 = '/Users/khyati/Documents/Resumes/JLR/project/data_sets/base_data.csv'
path2 = '/Users/khyati/Documents/Resumes/JLR/project/data_sets/options_data.csv'
path3 = '/Users/khyati/Documents/Resumes/JLR/project/data_sets/vehicle_line_mapping.csv'
path4 = '/Users/khyati/Documents/Resumes/JLR/project/logs/sample_logging.log'
# path1 = '/app/data_sets/base_data.csv'
# path2 = '/app/data_sets/options_data.csv'
# path3 = '/app/data_sets/vehicle_line_mapping.csv'
# path4 =  '/app/logs/sample_logging.log'
